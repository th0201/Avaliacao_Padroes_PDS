package avaliacaoParoes.q4Decorator;

public class Main {
    public static void main(String[] args) {
        Lanche lanche = new LancheNormal();
        System.out.println(lanche.montar());

        Lanche lancheGourmet = new LancheGourmet(lanche);
        System.out.println(lancheGourmet.montar());

        Lanche lancheVegano = new LancheVegano(lanche);
        System.out.println(lancheVegano.montar());
    }
    }
