package avaliacaoParoes.q4Decorator;

public class LancheNormal implements Lanche {
    @Override
    public String montar(){
        return "\nLanche normal com pão, queijo, presunto e salada";
    }

}
