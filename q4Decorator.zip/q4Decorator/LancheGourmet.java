package avaliacaoParoes.q4Decorator;

public class LancheGourmet extends LancheDecorator {
    public LancheGourmet(Lanche lanche){
        super(lanche);
    }

    @Override
    public String montar(){
        return super.montar() + " com igrendientes gourmet (Pão artesanal, queijo brie, presunto defumado)";
    }
    

}
