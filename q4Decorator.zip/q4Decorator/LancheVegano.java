package avaliacaoParoes.q4Decorator;

public class LancheVegano extends LancheDecorator {
    public LancheVegano(Lanche lanche){
        super(lanche);
    }

    @Override
    public String montar(){
        return super.montar() + " com ingredientes veganos (Pão integral, queijo vegano, presunto de soja)";
    }

}
