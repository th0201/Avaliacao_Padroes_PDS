package avaliacaoParoes.q4Decorator;

public interface Lanche {
    String montar();

}
