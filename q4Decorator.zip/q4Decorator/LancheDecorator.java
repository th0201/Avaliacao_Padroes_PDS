package avaliacaoParoes.q4Decorator;

public abstract class LancheDecorator implements Lanche {
    protected Lanche lanche;

    public LancheDecorator(Lanche lanche){
        this.lanche = lanche;
    }

    @Override
    public String montar(){
        return lanche.montar();
    }

}
