package avaliacaoParoes.q1Factory;

public interface Sanduiche {
    void preparar();

}
