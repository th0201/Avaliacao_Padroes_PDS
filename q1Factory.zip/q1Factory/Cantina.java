package avaliacaoParoes.q1Factory;

public class Cantina {
    private SanduicheFactory sanduicheFactory;

    public Cantina(SanduicheFactory sanduicheFactory){
        this.sanduicheFactory = sanduicheFactory;
    }

    public void fazerSanduiche(){
        Sanduiche sanduiche = sanduicheFactory.criarSanduiche();
        sanduiche.preparar();
    }
    
}
