package avaliacaoParoes.q1Factory;

public class SanduicheCGFactory extends SanduicheFactory {
    @Override
    public Sanduiche criarSanduiche(){
        return new Sanduiche(){
            @Override
            public void preparar(){
                System.out.println("---------------------------");
                System.out.println("SANDUÍCHE DA LANCHONETE CG:\n - Pão integral\n - Queijo Prato\n - Presuto de Frango\n - Sem verdura");
                System.out.println("---------------------------\n");
            }
        };
    }
    
}
