package avaliacaoParoes.q1Factory;

public abstract class SanduicheFactory {
    public abstract Sanduiche criarSanduiche();
}
