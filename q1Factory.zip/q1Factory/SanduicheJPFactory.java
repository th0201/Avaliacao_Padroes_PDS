package avaliacaoParoes.q1Factory;

public class SanduicheJPFactory extends SanduicheFactory{
    @Override
    public Sanduiche criarSanduiche() {
        return new Sanduiche() {
            @Override
            public void preparar() {
                System.out.println("---------------------------");
                System.out.println("SANDUÍCHE DA LANCHONETE JP:\n - Pão Francês\n - Queijo Mussarela\n - Presunto de Frango\n - Com Verdura");
                System.out.println("---------------------------\n");
            }
        };
    }
}
