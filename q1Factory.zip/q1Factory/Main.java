package avaliacaoParoes.q1Factory;

public class Main {
    public static void main(String[] args) {
        Cantina cantinaCG = new Cantina(new SanduicheCGFactory());
        cantinaCG.fazerSanduiche();

        Cantina cantinaJP = new Cantina(new SanduicheJPFactory());
        cantinaJP.fazerSanduiche();

        Cantina cantinaRT = new Cantina(new SanduicheRTFactory());
        cantinaRT.fazerSanduiche();

    }
    
}
