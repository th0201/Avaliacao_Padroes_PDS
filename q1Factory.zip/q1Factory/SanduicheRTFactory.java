package avaliacaoParoes.q1Factory;

public class SanduicheRTFactory extends SanduicheFactory {
    @Override
    public Sanduiche criarSanduiche() {
        return new Sanduiche() {
            @Override
            public void preparar() {
                System.out.println("---------------------------");
                System.out.println("SANDUÍCHE DA LANCHONETE RT:\n - Pão Bola\n - Queijo Cheedar\n - Presunto de Peru\n - Sem Verdura");
                System.out.println("---------------------------\n");
            }
        };
    }
}
