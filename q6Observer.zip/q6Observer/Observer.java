package avaliacaoParoes.q6Observer;

import java.util.ArrayList;
import java.util.List;

public interface Observer {
    List<Observer> observers = new ArrayList<Observer>();

    void addObserver(Observer observer);

    default void notifyObservers() {
        for (Observer observer : observers) {
            observer.update();
        }
    }

    void update();
}
