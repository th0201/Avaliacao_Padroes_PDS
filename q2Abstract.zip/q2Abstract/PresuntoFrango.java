package avaliacaoParoes.q2Abstract;

public class PresuntoFrango implements PresuntoIF {
    @Override
    public String getTipoPresunto() {
        return "Presunto de Frango";
    }

}

