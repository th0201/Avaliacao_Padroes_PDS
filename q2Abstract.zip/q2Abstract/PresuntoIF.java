package avaliacaoParoes.q2Abstract;

public interface PresuntoIF {
    String getTipoPresunto();

}
