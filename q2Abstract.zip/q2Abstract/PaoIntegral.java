package avaliacaoParoes.q2Abstract;

public class PaoIntegral implements PaoIF{
    @Override
    public String getTipoPao() {
        return "Pão Integral";
    }

}



