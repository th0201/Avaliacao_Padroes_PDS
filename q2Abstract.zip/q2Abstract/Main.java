package avaliacaoParoes.q2Abstract;

public class Main {
    public static void main(String[] args) {
        Cantina cantinaCG = new Cantina(new SanduichesIngredientesFactoryCG());
        cantinaCG.fazerSanduiche();

        Cantina cantinaJP = new Cantina(new SanduichesIngredientesFactoryJP());
        cantinaJP.fazerSanduiche();

        Cantina cantinaRT = new Cantina(new SanduichesIngredientesFactoryRT());
        cantinaRT.fazerSanduiche();
    }

}
