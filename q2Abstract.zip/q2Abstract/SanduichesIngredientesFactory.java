package avaliacaoParoes.q2Abstract;

public interface SanduichesIngredientesFactory {
    PaoIF criarPao();
    QueijoIF criarQueijo();
    PresuntoIF criarPresunto();
    SaladaIF criarSalada();

}
