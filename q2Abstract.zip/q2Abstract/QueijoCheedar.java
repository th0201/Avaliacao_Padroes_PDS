package avaliacaoParoes.q2Abstract;

public class QueijoCheedar implements QueijoIF {
    @Override
    public String getTipoQueijo() {
        return "Queijo Cheedar";
    }
}
