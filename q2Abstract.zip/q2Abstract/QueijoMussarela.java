package avaliacaoParoes.q2Abstract;

public class QueijoMussarela implements QueijoIF {
    @Override
    public String getTipoQueijo() {
        return "Queijo Mussarela";
    }
}
