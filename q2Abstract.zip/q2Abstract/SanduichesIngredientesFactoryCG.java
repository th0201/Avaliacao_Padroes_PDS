package avaliacaoParoes.q2Abstract;

public class SanduichesIngredientesFactoryCG implements SanduichesIngredientesFactory {
    @Override
    public PaoIF criarPao(){
        return new PaoIntegral();
    }

    @Override
    public QueijoIF criarQueijo(){
        return new QueijoPrato();
    }

    @Override
    public PresuntoIF criarPresunto(){
        return new PresuntoFrango();
    }

    @Override
    public SaladaIF criarSalada(){
        return new SemVerdura();
    }

}
