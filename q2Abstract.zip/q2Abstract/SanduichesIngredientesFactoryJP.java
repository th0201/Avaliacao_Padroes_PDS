package avaliacaoParoes.q2Abstract;

public class SanduichesIngredientesFactoryJP implements SanduichesIngredientesFactory{
    @Override
    public PaoIF criarPao() {
        return new PaoFrances();
    }

    @Override
    public QueijoIF criarQueijo() {
        return new QueijoMussarela();
    }

    @Override
    public PresuntoIF criarPresunto() {
        return new PresuntoFrango();
    }

    @Override
    public SaladaIF criarSalada() {
        return new ComVerdura();
    }
}
