package avaliacaoParoes.q2Abstract;

public interface SaladaIF {
    String getTipoSalada();

}
