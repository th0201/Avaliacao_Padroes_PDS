package avaliacaoParoes.q2Abstract;

public class ComVerdura implements SaladaIF {
    @Override
    public String getTipoSalada() {
        return "Com Verdura";
    }
}
