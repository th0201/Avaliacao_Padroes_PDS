package avaliacaoParoes.q2Abstract;

public interface PaoIF {
    String getTipoPao();

}
