package avaliacaoParoes.q2Abstract;

public class Sanduiche {
    private PaoIF pao;
    private QueijoIF queijo;
    private PresuntoIF presunto;
    private SaladaIF salada;

    public Sanduiche(SanduichesIngredientesFactory factory) {
        this.pao = factory.criarPao();
        this.queijo = factory.criarQueijo();
        this.presunto = factory.criarPresunto();
        this.salada = factory.criarSalada();
    }

    public void preparar() {
        System.out.println("\n-----------------------");
        System.out.println("Preparando sanduíche com:");
        System.out.println(pao.getTipoPao());
        System.out.println(queijo.getTipoQueijo());
        System.out.println(presunto.getTipoPresunto());
        System.out.println(salada.getTipoSalada());
    }

}
