package avaliacaoParoes.q2Abstract;

public interface QueijoIF {
    String getTipoQueijo();

}
