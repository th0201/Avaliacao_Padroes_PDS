package avaliacaoParoes.q2Abstract;

public class Cantina {
    private SanduichesIngredientesFactory factory;

    public Cantina(SanduichesIngredientesFactory factory) {
        this.factory = factory;
    }

    public void fazerSanduiche() {
        Sanduiche sanduiche = new Sanduiche(factory);
        sanduiche.preparar();
    }

}
