package avaliacaoParoes.q2Abstract;

public class PresuntoPeru implements PresuntoIF {
    @Override
    public String getTipoPresunto() {
        return "Presunto de Peru";
    }
    
}
