package avaliacaoParoes.q2Abstract;

public class SemVerdura implements SaladaIF {
    @Override
    public String getTipoSalada() {
        return "Sem Verdura";
    }

}
