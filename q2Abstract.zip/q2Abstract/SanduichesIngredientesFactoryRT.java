package avaliacaoParoes.q2Abstract;

public class SanduichesIngredientesFactoryRT implements SanduichesIngredientesFactory {
    @Override
    public PaoIF criarPao() {
        return new PaoBola();
    }

    @Override
    public QueijoIF criarQueijo() {
        return new QueijoCheedar();
    }

    @Override
    public PresuntoIF criarPresunto() {
        return new PresuntoPeru();
    }

    @Override
    public SaladaIF criarSalada() {
        return new SemVerdura();
    }

}
