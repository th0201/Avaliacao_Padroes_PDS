package avaliacaoParoes.q2Abstract;

public class PaoBola implements PaoIF {
    @Override
    public String getTipoPao() {
        return "Pão Bola";
    }

}
