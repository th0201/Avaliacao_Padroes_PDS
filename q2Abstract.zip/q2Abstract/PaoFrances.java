package avaliacaoParoes.q2Abstract;

public class PaoFrances implements PaoIF {
    @Override
    public String getTipoPao() {
        return "Pão Francês";
    }
}
