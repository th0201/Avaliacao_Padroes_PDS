package avaliacaoParoes.q2Abstract;

public class QueijoPrato implements QueijoIF {
    @Override
    public String getTipoQueijo() {
        return "Queijo Prato";
    }
}

