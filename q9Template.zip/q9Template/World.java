package avaliacaoPadroes.q9Template;

public class World extends Relatorio{
    @Override
    protected void gerarArquivo() {
        System.out.println("Gerando arquivo World...");
    }
}
