package avaliacaoPadroes.q9Template;

public abstract class Relatorio {
public final void gerarRelatorio() {
    gerarArquivo();
}

protected abstract void gerarArquivo();
}
