package avaliacaoPadroes.q9Template;

public class PDF extends Relatorio{
    @Override
    protected void gerarArquivo() {
        System.out.println("Gerando arquivo PDF...");
    }
}
