package avaliacaoPadroes.q9Template;

public class Main {
    public static void main(String[] args) {
        Relatorio pdf = new PDF();
        pdf.gerarRelatorio();

        System.out.println();

        Relatorio exel = new Exel();
        exel.gerarRelatorio();

        System.out.println();

        Relatorio world = new World();
        world.gerarRelatorio();
    }
}
