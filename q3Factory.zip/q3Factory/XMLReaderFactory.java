package avaliacaoParoes.q3Factory;


public class XMLReaderFactory {
    createXMLReader();
    }
    
