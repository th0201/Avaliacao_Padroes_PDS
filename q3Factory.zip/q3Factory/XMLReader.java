package avaliacaoParoes.q3Factory;

import java.io.InputStream;

public interface XMLReader {
    public void setContentHandler(ContentHandler handler):
    public void parse(InputStream is);
}
